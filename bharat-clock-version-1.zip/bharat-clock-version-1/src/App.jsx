import ClockHeading from './componts/ClockHeading'
import ClockSigon from './componts/ClockSigon'
import CurrentTime from './componts/CurrentTime'
import './App.css'
import "bootstrap/dist/css/bootstrap.min.css"


function App() {
  return (
      <center>
    <ClockHeading></ClockHeading>
    <ClockSigon></ClockSigon>
    <CurrentTime></CurrentTime>
    </center>
  );
}

export default App
