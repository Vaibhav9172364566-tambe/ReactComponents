let ClockSigon =() =>{
 return <p className="lead">This is the clock shows the time in Bhartat at all times.</p>
}
export default ClockSigon;