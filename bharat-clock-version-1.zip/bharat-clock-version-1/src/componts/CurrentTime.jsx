let CurrentTime =() =>{
    let time=new Date();
    return <p className="lead">This is the Current time {time.toLocaleDateString()} -{""}{time.toLocaleDateString()}</p>
   }
   export default CurrentTime;